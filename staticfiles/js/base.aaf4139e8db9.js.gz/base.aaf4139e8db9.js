function disable_on_click() {
    var element = document.getElementById('btn');
    element.setAttribute("disabled", "disabled");
  }